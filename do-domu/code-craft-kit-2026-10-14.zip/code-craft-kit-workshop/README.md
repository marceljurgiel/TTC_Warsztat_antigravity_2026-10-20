# Code Craft Kit dla Google Antigravity

Agent **code-engineer** i 28 skilli, które uczą agenta pracować jak zdyscyplinowany inżynier:
najpierw zrozumieć, potem zaplanować, pisać testy przed kodem, szukać przyczyny błędu zamiast
zgadywać i nie mówić „gotowe”, dopóki tego nie sprawdzi.

- **superpowers** (Jesse Vincent): metoda pracy. Burza mózgów, plan, TDD, systematyczne
  debugowanie, przegląd kodu, weryfikacja, praca z podagentami.
- **agent-skills** (Addy Osmani, Google): wiedza inżynierska. Bezpieczeństwo, wydajność, projekt
  API, CI/CD, obserwowalność, dokumentacja, wdrożenia, migracje.

Agent używa wyłącznie tych 28 skilli, nawet jeśli masz zainstalowane inne.

## Wymagania

| Co | Po co |
| --- | --- |
| Google Antigravity (aplikacja, IDE albo CLI `agy`) | do uruchomienia agenta |
| Git | gałęzie, worktree, przegląd zmian |
| Bash | skrypty superpowers do pracy z podagentami; na Windowsie Git Bash |
| Node.js (opcjonalnie) | wizualna burza mózgów w przeglądarce |
| Chrome DevTools MCP (opcjonalnie) | skill `browser-testing-with-devtools` |

## Instalacja

Wybierz jeden sposób.

**macOS / Linux**

```bash
./install.sh
```

**Windows (PowerShell)**

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

**CLI Antigravity**

```bash
agy plugin install ./code-craft-kit
```

**Ręcznie:** skopiuj folder `code-craft-kit` do `~/.gemini/config/plugins/`, żeby działał we
wszystkich projektach. Jeśli ma działać tylko w jednym projekcie, skopiuj go do
`<projekt>/.agents/plugins/`.

Sprawdzenie: `agy plugin list` powinno pokazać `code-craft-kit`.

## Uruchomienie

**CLI:**

```bash
agy --agent code-engineer
```

Możesz też w trakcie sesji wpisać `/agents` i wybrać **code-engineer** jako agenta głównego.

**Aplikacja i IDE:** wybierz **code-engineer** na liście agentów. Możesz też poprosić zwykłego
agenta: „Użyj agenta code-engineer, żeby…”.

## Jak wygląda praca z agentem

Agent nie zaczyna od pisania kodu. Przy nowej funkcji najpierw zadaje pytania, po jednym naraz,
proponuje 2–3 podejścia i pokazuje projekt do akceptacji. Potem pisze plan z małymi krokami.
Każdy krok zaczyna od testu, który na razie nie przechodzi. Na koniec zleca przegląd kodu i
uruchamia testy, zanim powie, że skończył.

To celowe. Jeśli chcesz szybciej, powiedz wprost, np. „pomiń burzę mózgów” albo „bez worktree”.
Agent pominie ten krok i napisze, co pominął.

Przykładowe polecenia:

```text
Dodaj logowanie użytkowników do mojej aplikacji Express.
```

```text
Testy w checkout.test.ts zaczęły padać po ostatnim merge’u. Znajdź przyczynę.
```

```text
Zrób przegląd bezpieczeństwa endpointów w src/api przed wdrożeniem.
```

```text
Strona produktu ładuje się 4 sekundy. Przyspiesz ją.
```

## Co jest w środku

**Metoda pracy (superpowers), 15 skilli**

| Skill | Kiedy agent go używa |
| --- | --- |
| `using-superpowers` | na początku każdego zadania: zasady korzystania ze skilli |
| `brainstorming` | nowa funkcja albo zmiana zachowania: pytania, podejścia, projekt do akceptacji |
| `writing-plans` | zaakceptowany projekt: plan z małymi, sprawdzalnymi krokami |
| `subagent-driven-development` | realizacja planu przez podagentów, z przeglądem po każdym kroku |
| `executing-plans` | realizacja planu w jednej sesji |
| `dispatching-parallel-agents` | kilka niezależnych problemów naraz |
| `test-driven-development` | każda logika i poprawka: najpierw test, który pada |
| `systematic-debugging` | błąd, padający test, dziwne zachowanie: najpierw przyczyna, potem poprawka |
| `using-git-worktrees` | praca w osobnym katalogu roboczym |
| `requesting-code-review` | po skończonym kroku lub funkcji |
| `receiving-code-review` | gdy przychodzą uwagi z przeglądu: najpierw sprawdzić, potem przyjąć |
| `verification-before-completion` | zanim padnie „gotowe”: uruchomić i przeczytać wynik |
| `finishing-a-development-branch` | scalenie, PR albo porzucenie gałęzi |
| `writing-skills` | gdy chcesz napisać własny skill |
| `diagnosing-superpowers` | gdy sesja poszła źle i chcesz wiedzieć dlaczego |

**Wiedza inżynierska (Addy Osmani), 13 skilli**

| Skill | Obszar |
| --- | --- |
| `api-and-interface-design` | publiczne API, granice modułów, kontrakty |
| `security-and-hardening` | dane od użytkownika, uwierzytelnianie, sekrety, pliki, odpowiedzi LLM |
| `performance-optimization` | wolne strony i zapytania, rozmiar paczki |
| `observability-and-instrumentation` | logi, metryki, śledzenie, alerty |
| `ci-cd-and-automation` | potoki budowania, testów i wdrożeń |
| `documentation-and-adrs` | dokumentacja i zapis decyzji (ADR) |
| `deprecation-and-migration` | wycofywanie i zastępowanie systemów, API i pól |
| `git-workflow-and-versioning` | commity, gałęzie, wersjonowanie |
| `code-simplification` | refaktoryzacja dla czytelności bez zmiany zachowania |
| `frontend-ui-engineering` | interfejsy: dostępność, responsywność, stany |
| `browser-testing-with-devtools` | testy w prawdziwej przeglądarce (wymaga Chrome DevTools MCP) |
| `shipping-and-launch` | przygotowanie wdrożenia na produkcję |
| `source-driven-development` | decyzje oparte na oficjalnej dokumentacji |

W folderze `code-craft-kit/references/` są listy kontrolne Addy’ego (bezpieczeństwo, wydajność,
dostępność, obserwowalność, definicja „gotowe”, wzorce testów), z których korzystają te skille.

Z paczki Addy’ego pominąłem 12 skilli, które dublują metodę superpowers (TDD, debugowanie,
planowanie, specyfikacja, burza mózgów, przegląd kodu i podobne). Dzięki temu agent ma jedną
metodę pracy zamiast dwóch sprzecznych.

## Chrome DevTools MCP (opcjonalnie)

Skill `browser-testing-with-devtools` potrzebuje serwera MCP Chrome DevTools. W Antigravity
dodasz go poleceniem:

```bash
agy mcp add chrome-devtools -- npx -y chrome-devtools-mcp@latest --isolated
```

Instrukcja w samym skillu dotyczy Claude Code (`.mcp.json`), więc w Antigravity jej nie używaj.
Tej konfiguracji nie testowałem z agentem `code-engineer`. Bez serwera MCP agent powie, że nie może
testować w przeglądarce, i sprawdzi kod inaczej.

## Porównanie z paczką i bez niej

Gdy plugin jest włączony, jego skille widzi też zwykły agent. Żeby porównać wyniki:

```bash
agy plugin disable code-craft-kit   # bez skilli
agy plugin enable code-craft-kit    # ze skillami
```

## Odinstalowanie

```bash
agy plugin uninstall code-craft-kit
```

albo usuń folder `~/.gemini/config/plugins/code-craft-kit`.

## Autorzy, licencje i wersje

| Paczka | Autor | Licencja | Wersja w tej paczce |
| --- | --- | --- | --- |
| [superpowers](https://github.com/obra/superpowers) | Jesse Vincent | MIT | 7.0.0, commit `bb92a77` (9.10.2026) |
| [agent-skills](https://github.com/addyosmani/agent-skills) | Addy Osmani | MIT | commit `aeac41d` (13.10.2026), 13 z 25 skilli |

Pełne teksty licencji są w `code-craft-kit/LICENSES/`. Skille i listy kontrolne są skopiowane bez
zmian. Od autora paczki pochodzą tylko agent `code-engineer`, ten opis i skrypty instalacyjne.

Testowane z Antigravity CLI 1.3.3.
