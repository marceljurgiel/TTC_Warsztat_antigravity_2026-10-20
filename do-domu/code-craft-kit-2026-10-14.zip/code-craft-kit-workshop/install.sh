#!/usr/bin/env bash
# Instaluje plugin code-craft-kit globalnie dla Google Antigravity (aplikacja, IDE i CLI).
set -euo pipefail

NAME="code-craft-kit"
SRC="$(cd "$(dirname "$0")" && pwd)/$NAME"
DEST_DIR="$HOME/.gemini/config/plugins"
DEST="$DEST_DIR/$NAME"

if [ ! -f "$SRC/plugin.json" ]; then
  echo "Nie znaleziono $SRC/plugin.json. Uruchom skrypt z rozpakowanego folderu paczki." >&2
  exit 1
fi

mkdir -p "$DEST_DIR"
if [ -e "$DEST" ]; then
  # Kopia poza folderem plugins/, inaczej Antigravity wczytałby ją jako drugi plugin.
  BACKUP_DIR="$HOME/.gemini/config/plugins-backup"
  mkdir -p "$BACKUP_DIR"
  BACKUP="$BACKUP_DIR/$NAME-$(date +%Y%m%d-%H%M%S)"
  mv "$DEST" "$BACKUP"
  echo "Poprzednia wersja przeniesiona do: $BACKUP"
fi
cp -R "$SRC" "$DEST"
chmod +x "$DEST"/skills/*/scripts/* 2>/dev/null || true
echo "Zainstalowano: $DEST"

if command -v git >/dev/null 2>&1; then
  echo "$(git --version): OK"
else
  echo "Uwaga: brak Gita. Superpowers używa go do gałęzi, worktree i przeglądu zmian."
fi

if command -v node >/dev/null 2>&1; then
  echo "Node.js $(node --version): OK (wizualna burza mózgów)"
else
  echo "Informacja: brak Node.js. Wizualna burza mózgów w przeglądarce nie zadziała; reszta tak."
fi

if command -v agy >/dev/null 2>&1; then
  agy plugin validate "$DEST" || true
fi

echo
echo "Gotowe. Uruchom agenta: agy --agent code-engineer"
echo "W aplikacji lub IDE wybierz agenta code-engineer z listy agentów."
