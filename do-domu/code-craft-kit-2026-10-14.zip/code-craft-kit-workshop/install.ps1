# Instaluje plugin code-craft-kit globalnie dla Google Antigravity (aplikacja, IDE i CLI).
$ErrorActionPreference = 'Stop'

$Name = 'code-craft-kit'
$Src = Join-Path $PSScriptRoot $Name
$DestDir = Join-Path $HOME '.gemini\config\plugins'
$Dest = Join-Path $DestDir $Name

if (-not (Test-Path (Join-Path $Src 'plugin.json'))) {
  Write-Error "Nie znaleziono $Src\plugin.json. Uruchom skrypt z rozpakowanego folderu paczki."
}

New-Item -ItemType Directory -Force -Path $DestDir | Out-Null
if (Test-Path $Dest) {
  # Kopia poza folderem plugins\, inaczej Antigravity wczytałby ją jako drugi plugin.
  $BackupDir = Join-Path $HOME '.gemini\config\plugins-backup'
  New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
  $Backup = Join-Path $BackupDir "$Name-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
  Move-Item $Dest $Backup
  Write-Host "Poprzednia wersja przeniesiona do: $Backup"
}
Copy-Item -Recurse $Src $Dest
Write-Host "Zainstalowano: $Dest"

if (Get-Command git -ErrorAction SilentlyContinue) {
  Write-Host "$(& git --version): OK"
} else {
  Write-Host 'Uwaga: brak Gita. Superpowers używa go do gałęzi, worktree i przeglądu zmian.'
}

if (Get-Command bash -ErrorAction SilentlyContinue) {
  Write-Host 'Bash: OK'
} else {
  Write-Host 'Uwaga: brak Basha. Skrypty superpowers do pracy z podagentami wymagają Git Bash (instaluje się razem z Git for Windows).'
}

if (Get-Command node -ErrorAction SilentlyContinue) {
  Write-Host "Node.js $(& node --version): OK (wizualna burza mózgów)"
} else {
  Write-Host 'Informacja: brak Node.js. Wizualna burza mózgów w przeglądarce nie zadziała; reszta tak.'
}

if (Get-Command agy -ErrorAction SilentlyContinue) {
  & agy plugin validate $Dest
}

Write-Host ''
Write-Host 'Gotowe. Uruchom agenta: agy --agent code-engineer'
Write-Host 'W aplikacji lub IDE wybierz agenta code-engineer z listy agentów.'
