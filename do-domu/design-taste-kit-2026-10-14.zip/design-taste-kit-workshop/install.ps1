# Instaluje plugin design-taste-kit globalnie dla Google Antigravity (aplikacja, IDE i CLI).
$ErrorActionPreference = 'Stop'

$Name = 'design-taste-kit'
$Src = Join-Path $PSScriptRoot $Name
$DestDir = Join-Path $HOME '.gemini\config\plugins'
$Dest = Join-Path $DestDir $Name

if (-not (Test-Path (Join-Path $Src 'plugin.json'))) {
  Write-Error "Nie znaleziono $Src\plugin.json. Uruchom skrypt z rozpakowanego folderu paczki."
}

New-Item -ItemType Directory -Force -Path $DestDir | Out-Null
if (Test-Path $Dest) {
  # Kopia poza folderem plugins\, inaczej Antigravity wczytałby ją jako drugi plugin.
  $BackupDir = Join-Path $HOME '.gemini\config\plugins-backup'
  New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
  $Backup = Join-Path $BackupDir "$Name-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
  Move-Item $Dest $Backup
  Write-Host "Poprzednia wersja przeniesiona do: $Backup"
}
Copy-Item -Recurse $Src $Dest
Write-Host "Zainstalowano: $Dest"

# Wymagania skryptów taste-skill (zrzuty ekranu i zdjęcia). Bez nich agent działa, ale nie obejrzy strony.
$node = Get-Command node -ErrorAction SilentlyContinue
if ($node) {
  $major = [int](& node -p 'process.versions.node.split(".")[0]')
  if ($major -ge 22) { Write-Host "Node.js $(& node --version): OK" }
  else { Write-Host "Uwaga: Node.js $(& node --version). Inspektor taste-skill wymaga wersji 22 lub nowszej." }
} else {
  Write-Host 'Uwaga: brak Node.js 22+. Bez niego agent nie zrobi zrzutów ekranu.'
}

$browsers = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
)
$found = $browsers | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if ($found) { Write-Host "Przeglądarka do zrzutów: OK ($found)" }
else { Write-Host 'Uwaga: nie znaleziono Chrome ani Edge. Bez nich agent nie zrobi zrzutów ekranu.' }

if (Get-Command agy -ErrorAction SilentlyContinue) {
  & agy plugin validate $Dest
}

Write-Host ''
Write-Host 'Gotowe. Uruchom agenta: agy --agent design-engineer'
Write-Host 'W aplikacji lub IDE wybierz agenta design-engineer z listy agentów.'
