# Design Taste Kit dla Google Antigravity

Agent **design-engineer** i 29 skilli, które sprawiają, że strony i aplikacje generowane przez AI
wyglądają na zaprojektowane, a nie na wygenerowane z szablonu.

- **taste-skill** (Leonxlnx): kierunek artystyczny, zakazy typowych „AI-owych” wzorców, pętla
  zrzutów ekranu w prawdziwej przeglądarce.
- **Skille Emila Kowalskiego**: dopracowanie detali, ruch i animacje, zachowanie na telefonie,
  testy na najgorszych danych.

Agent używa wyłącznie tych 29 skilli, nawet jeśli masz zainstalowane inne.

## Wymagania

| Co | Po co |
| --- | --- |
| Google Antigravity (aplikacja, IDE albo CLI `agy`) | do uruchomienia agenta |
| Node.js 22 lub nowszy | skrypty taste-skill: losowanie kierunku, lint, inspektor |
| Chrome, Edge albo Chromium | inspektor robi zrzuty ekranu przy 1440, 768 i 390 px |
| Internet | wyszukiwanie zdjęć na wolnych licencjach (Openverse, Wikimedia, muzea) |

Bez Node’a i przeglądarki agent nadal działa, ale nie obejrzy swojej strony i powie o tym w raporcie.

## Instalacja

Wybierz jeden sposób.

**macOS / Linux**

```bash
./install.sh
```

**Windows (PowerShell)**

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

**CLI Antigravity**

```bash
agy plugin install ./design-taste-kit
```

**Ręcznie:** skopiuj folder `design-taste-kit` do `~/.gemini/config/plugins/`, żeby działał we
wszystkich projektach. Jeśli ma działać tylko w jednym projekcie, skopiuj go do
`<projekt>/.agents/plugins/`.

Sprawdzenie: `agy plugin list` powinno pokazać `design-taste-kit`.

## Uruchomienie

**CLI:**

```bash
agy --agent design-engineer
```

Możesz też w trakcie sesji wpisać `/agents` i wybrać **design-engineer** jako agenta głównego.

**Aplikacja i IDE:** wybierz **design-engineer** na liście agentów. Możesz też poprosić
zwykłego agenta: „Użyj agenta design-engineer, żeby zrobić…”.

## Jak pisać polecenia

Im krótsze polecenie, tym więcej decyzji podejmuje skill. Opisz **co** ma powstać i jakie są
twarde ograniczenia. Nie opisuj, **jak** ma wyglądać.

```text
Zrób stronę jednodniowej konferencji o Google Cloud: dzisiejsza data, miejsce i harmonogram
8 prelekcji z godzinną przerwą obiadową. Prelekcja ma ID, tytuł, 1–2 prelegentów (imię, nazwisko,
LinkedIn), 1–2 kategorie, opis i godzinę. Wyszukiwanie po tytule, prelegencie i kategorii.
Przykładowe dane. Jeden plik index.html, bez bibliotek i serwera.
```

```text
Stwórz aplikację z minutnikiem Pomodoro. Spokojny, estetyczny wygląd.
```

```text
Strona małej palarni kawy z Krakowa: oferta, sklep z 6 kawami, godziny otwarcia, kontakt.
```

Ograniczenia z polecenia zawsze wygrywają ze skillami. Jeśli napiszesz „jeden plik, bez bibliotek”,
agent nie użyje Reacta, Tailwinda, GSAP ani fontów z CDN i powie, czym je zastąpił.

## Przydatne komendy

| Komenda | Co robi |
| --- | --- |
| `/review-animations` | surowa recenzja animacji w projekcie |
| `/prototype` | kilka naprawdę różnych wersji komponentu z przełącznikiem do porównania |
| `/pick-ui-library` | dobór biblioteki do zadania (wykresy, OTP, drag and drop…) |

Te trzy skille autor ustawił tak, że uruchamia je tylko użytkownik, nigdy agent sam z siebie.

## Porównanie ze skillami i bez nich

Gdy plugin jest włączony, jego skille widzi też zwykły agent. Żeby porównać wyniki:

```bash
agy plugin disable design-taste-kit   # bez skilli
agy plugin enable design-taste-kit    # ze skillami
```

## Co jest w środku

**Kierunek artystyczny (taste-skill)**

| Skill | Kiedy agent go używa |
| --- | --- |
| `design-taste-frontend` | domyślnie dla stron www: losuje kierunek z biblioteki 20 kierunków, szuka prawdziwych zdjęć, sprawdza stronę w przeglądarce i poprawia ją w maksymalnie 3 rundach |
| `minimalist-ui` | ekrany aplikacji, dashboardy: ciepła monochromia, płaskie układy |
| `high-end-visual-design` | aplikacje i strony w stylu agencji premium |
| `industrial-brutalist-ui` | gdy poprosisz o styl brutalistyczny, terminalowy albo szwajcarski |
| `redesign-existing-projects` | przeróbka istniejącej strony |
| `stitch-design-taste` | plik DESIGN.md dla Google Stitch |
| `gpt-taste` | animacje sterowane przewijaniem w GSAP, tylko gdy pozwolisz na biblioteki |
| `full-output-enforcement` | pilnuje, żeby długie pliki nie były ucinane |
| `imagegen-frontend-web`, `image-to-code`, `imagegen-frontend-mobile`, `brandkit` | gdy chcesz wygenerowanych makiet, obrazów albo identyfikacji marki |
| `design-taste-frontend-v2-experimental`, `design-taste-frontend-v1` | starsze wersje, tylko gdy o nie poprosisz |

**Dopracowanie, ruch i telefon (Emil Kowalski)**

| Skill | Kiedy agent go używa |
| --- | --- |
| `emil-design-eng` | zawsze: detale, stany, informacja zwrotna, „czucie” interfejsu |
| `mobile-native` | zawsze przy stronach: efekt najechania tylko dla myszy, pola 16 px, wcięcie ekranu |
| `animate` | przed napisaniem każdej animacji |
| `apple-design` | sprężyny, gesty, arkusze, głębia, typografia w stylu Apple |
| `animation-performance` | gdy animacja się tnie albo trzeba wybrać animowane właściwości |
| `animation-vocabulary` | gdy opisujesz efekt, nie znając jego nazwy |
| `find-animation-opportunities`, `improve-animations` | gdy chcesz ożywić istniejący interfejs |
| `break-ui` | test interfejsu na najgorszych danych: długie nazwy, emoji, zero elementów |
| `review-animations`, `prototype`, `pick-ui-library` | tylko na twoją komendę (patrz wyżej) |
| `write-swift`, `animate-expo`, `ask-sonner` | Swift, React Native/Expo, biblioteka Sonner |

## Co agent sprawdza sam

Oprócz reguł ze skilli agent ma własną listę kontrolną. Te błędy w naszych testach prześlizgnęły
się przez wszystkie skille:

- element ukryty atrybutem `hidden` naprawdę znika;
- wyszukiwarka pokazuje liczbę wyników i daje wyjście z pustego stanu;
- widoczny fokus, kontrast policzony, a nie zgadnięty;
- `prefers-reduced-motion`;
- cofanie zamiast systemowego `confirm()`;
- polska typografia: półpauza w zakresach (`09:00–17:00`), daty przez `Intl`.

## Pliki robocze

Skrypty taste-skill tworzą w projekcie folder `.taste-skill/` (zrzuty, raporty, wybrany kierunek),
a historię losowań zapisują w `~/.taste-skill/`. Pobrane zdjęcia trafiają do `assets/`, a ich autorzy
i licencje do `assets/credits.json`. Agent podaje te informacje na stronie.

## Odinstalowanie

```bash
agy plugin uninstall design-taste-kit
```

albo usuń folder `~/.gemini/config/plugins/design-taste-kit`.

## Autorzy, licencje i wersje

| Paczka | Autor | Licencja | Wersja w tej paczce |
| --- | --- | --- | --- |
| [taste-skill](https://github.com/Leonxlnx/taste-skill) | Leonxlnx | MIT | commit `f624f37` (14.10.2026), wydanie 2.0.0 |
| [skills](https://github.com/emilkowalski/skills) | Emil Kowalski | MIT | commit `2d22863` (11.10.2026) |

Pełne teksty licencji są w `design-taste-kit/LICENSES/`. Skille są skopiowane bez zmian. Od autora
paczki pochodzą tylko agent `design-engineer`, ten opis i skrypty instalacyjne.

Testowane z Antigravity CLI 1.3.3. W tej wersji CLI agent nie ma wbudowanego narzędzia
przeglądarki, dlatego zrzuty ekranu robi skrypt `inspect.mjs` z taste-skill.
