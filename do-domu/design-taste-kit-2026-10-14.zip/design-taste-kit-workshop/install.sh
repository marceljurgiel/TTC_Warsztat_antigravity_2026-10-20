#!/usr/bin/env bash
# Instaluje plugin design-taste-kit globalnie dla Google Antigravity (aplikacja, IDE i CLI).
set -euo pipefail

NAME="design-taste-kit"
SRC="$(cd "$(dirname "$0")" && pwd)/$NAME"
DEST_DIR="$HOME/.gemini/config/plugins"
DEST="$DEST_DIR/$NAME"

if [ ! -f "$SRC/plugin.json" ]; then
  echo "Nie znaleziono $SRC/plugin.json. Uruchom skrypt z rozpakowanego folderu paczki." >&2
  exit 1
fi

mkdir -p "$DEST_DIR"
if [ -e "$DEST" ]; then
  # Kopia poza folderem plugins/, inaczej Antigravity wczytałby ją jako drugi plugin.
  BACKUP_DIR="$HOME/.gemini/config/plugins-backup"
  mkdir -p "$BACKUP_DIR"
  BACKUP="$BACKUP_DIR/$NAME-$(date +%Y%m%d-%H%M%S)"
  mv "$DEST" "$BACKUP"
  echo "Poprzednia wersja przeniesiona do: $BACKUP"
fi
cp -R "$SRC" "$DEST"
echo "Zainstalowano: $DEST"

# Wymagania skryptów taste-skill (zrzuty ekranu i zdjęcia). Bez nich agent działa, ale nie obejrzy strony.
if command -v node >/dev/null 2>&1; then
  major="$(node -p 'process.versions.node.split(".")[0]')"
  if [ "$major" -ge 22 ]; then
    echo "Node.js $(node --version): OK"
  else
    echo "Uwaga: Node.js $(node --version). Inspektor taste-skill wymaga wersji 22 lub nowszej."
  fi
else
  echo "Uwaga: brak Node.js 22+. Bez niego agent nie zrobi zrzutów ekranu."
fi

browser=""
for b in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge; do
  if command -v "$b" >/dev/null 2>&1; then browser="$b"; break; fi
done
if [ -z "$browser" ] && [ -d "/Applications/Google Chrome.app" ]; then browser="Google Chrome"; fi
if [ -z "$browser" ] && [ -d "/Applications/Microsoft Edge.app" ]; then browser="Microsoft Edge"; fi
if [ -n "$browser" ]; then
  echo "Przeglądarka do zrzutów ($browser): OK"
else
  echo "Uwaga: nie znaleziono Chrome, Edge ani Chromium. Bez nich agent nie zrobi zrzutów ekranu."
fi

if command -v agy >/dev/null 2>&1; then
  agy plugin validate "$DEST" || true
fi

echo
echo "Gotowe. Uruchom agenta: agy --agent design-engineer"
echo "W aplikacji lub IDE wybierz agenta design-engineer z listy agentów."
